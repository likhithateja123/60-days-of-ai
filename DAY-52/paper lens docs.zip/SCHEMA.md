# SCHEMA.md
## PaperLens - Database Design (SQLite)

---

## 1. Entity Relationship Diagram

```mermaid
erDiagram
    USERS ||--o{ SESSIONS : "creates"
    SESSIONS ||--|{ PAPERS : "contains 2-5"
    SESSIONS ||--|| ANALYSIS_RESULTS : "produces 1"

    USERS {
        int id PK
        string email UK
        string password_hash
        datetime created_at
    }

    SESSIONS {
        int id PK
        int user_id FK
        string title
        string status
        datetime created_at
    }

    PAPERS {
        int id PK
        int session_id FK
        string filename
        string file_path
        text extracted_text
        string extraction_status
        datetime uploaded_at
    }

    ANALYSIS_RESULTS {
        int id PK
        int session_id FK
        json summaries
        json comparison_table
        json research_gaps
        text survey_draft
        string status
        datetime generated_at
    }
```

---

## 2. Tables

### users
| Field | Type | Constraints |
|---|---|---|
| id | INTEGER | PK, AUTOINCREMENT |
| email | TEXT | UNIQUE, NOT NULL |
| password_hash | TEXT | NOT NULL |
| created_at | DATETIME | NOT NULL, DEFAULT CURRENT_TIMESTAMP |

Notes: No roles, no email verification field - consistent with "simple auth" assumption.

---

### sessions
Represents one "analysis run" - one upload batch of 2-5 papers and its results.

| Field | Type | Constraints |
|---|---|---|
| id | INTEGER | PK, AUTOINCREMENT |
| user_id | INTEGER | FK -> users.id, NOT NULL |
| title | TEXT | NULLABLE (optional user-given label) |
| status | TEXT | NOT NULL, CHECK IN ('pending','processing','complete','failed') |
| created_at | DATETIME | NOT NULL, DEFAULT CURRENT_TIMESTAMP |

Notes: A "session" is scoped to one user (no sharing - matches "no multi-user collaboration").

---

### papers
| Field | Type | Constraints |
|---|---|---|
| id | INTEGER | PK, AUTOINCREMENT |
| session_id | INTEGER | FK -> sessions.id, NOT NULL |
| filename | TEXT | NOT NULL |
| file_path | TEXT | NOT NULL |
| extracted_text | TEXT | NULLABLE (populated after extraction) |
| extraction_status | TEXT | NOT NULL, CHECK IN ('pending','success','failed') |
| uploaded_at | DATETIME | NOT NULL, DEFAULT CURRENT_TIMESTAMP |

Constraint (application-level, not DB-level): A session must have between 2 and 5 papers - enforced in the Upload Router, not via SQL CHECK (SQLite can't easily count sibling rows in a CHECK constraint).

---

### analysis_results
| Field | Type | Constraints |
|---|---|---|
| id | INTEGER | PK, AUTOINCREMENT |
| session_id | INTEGER | FK -> sessions.id, NOT NULL, UNIQUE (1:1 with session) |
| summaries | JSON (stored as TEXT) | NULLABLE until generated |
| comparison_table | JSON (stored as TEXT) | NULLABLE until generated |
| research_gaps | JSON (stored as TEXT) | NULLABLE until generated |
| survey_draft | TEXT | NULLABLE until generated |
| status | TEXT | NOT NULL, CHECK IN ('pending','processing','complete','failed') |
| generated_at | DATETIME | NULLABLE |

---

## 3. Relationships Summary

- One user -> many sessions (one per upload batch)
- One session -> 2 to 5 papers (enforced in application logic)
- One session -> exactly one analysis_results row

---

## 4. Validation Against PRD

| PRD Requirement | Schema Support |
|---|---|
| Upload 2-5 PDF papers | papers table linked to sessions, batch-size enforced at API layer |
| Structured AI summaries | analysis_results.summaries (JSON, one entry per paper) |
| Multi-paper comparison table | analysis_results.comparison_table (JSON) |
| Research gap detection | analysis_results.research_gaps (JSON) |
| Literature survey draft | analysis_results.survey_draft (TEXT) |
| No multi-user collaboration | Sessions are strictly user-scoped, no sharing table exists |
| No citation graphs | No graph/edge tables - intentionally absent |

Schema fully covers approved PRD scope with no unnecessary tables added.
