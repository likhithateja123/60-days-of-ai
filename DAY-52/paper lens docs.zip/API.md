# API.md
## PaperLens - API Design (v1)

Base URL: `/api/v1`
Auth scheme: `Authorization: Bearer <JWT>` (except signup/login)

---

## 1. Auth Endpoints

### POST /auth/signup
- **Purpose:** Create a new user account.
- **Auth:** None
- **Request:**
```json
{ "email": "string", "password": "string (min 8 chars)" }
```
- **Response (201):**
```json
{ "id": 1, "email": "user@example.com", "created_at": "2026-07-22T00:00:00Z" }
```
- **Validation:** Valid email format; password >= 8 chars; email not already registered.
- **Errors:**
  - 400 - Invalid email format
  - 400 - Password too short
  - 409 - Email already registered

---

### POST /auth/login
- **Purpose:** Authenticate user, issue JWT.
- **Auth:** None
- **Request:**
```json
{ "email": "string", "password": "string" }
```
- **Response (200):**
```json
{ "access_token": "jwt-string", "token_type": "bearer" }
```
- **Validation:** Email exists; password matches hash.
- **Errors:**
  - 401 - Invalid credentials
  - 400 - Missing fields

---

## 2. Paper Upload Endpoints

### POST /papers/upload
- **Purpose:** Upload 2-5 PDF papers, create a new session, trigger text extraction.
- **Auth:** Required
- **Request:** `multipart/form-data`
```
files: [file1.pdf, file2.pdf, ...]  (2 to 5 files)
title: "optional session title"
```
- **Response (201):**
```json
{
  "session_id": 12,
  "status": "processing",
  "papers": [
    { "id": 1, "filename": "paper1.pdf", "extraction_status": "pending" },
    { "id": 2, "filename": "paper2.pdf", "extraction_status": "pending" }
  ]
}
```
- **Validation:** File count between 2-5; each file must be a valid PDF (MIME check); max file size (e.g. 15MB per file, to be confirmed).
- **Errors:**
  - 400 - Fewer than 2 or more than 5 files
  - 400 - Non-PDF file included
  - 413 - File too large
  - 401 - Missing/invalid JWT

---

### GET /papers/session/{session_id}
- **Purpose:** Get status and metadata of an upload session.
- **Auth:** Required (must own session)
- **Request:** None (path param `session_id`)
- **Response (200):**
```json
{
  "session_id": 12,
  "status": "processing",
  "papers": [
    { "id": 1, "filename": "paper1.pdf", "extraction_status": "success" },
    { "id": 2, "filename": "paper2.pdf", "extraction_status": "success" }
  ]
}
```
- **Validation:** Session must belong to requesting user.
- **Errors:**
  - 404 - Session not found
  - 403 - Session belongs to another user
  - 401 - Missing/invalid JWT

---

## 3. Analysis Endpoints

### POST /analysis/{session_id}/run
- **Purpose:** Trigger the AI analysis pipeline (summarize -> compare -> detect gaps -> draft survey) for a session whose papers are fully extracted.
- **Auth:** Required (must own session)
- **Request:** None (path param `session_id`)
- **Response (202):**
```json
{ "session_id": 12, "status": "processing" }
```
- **Validation:** All papers in session must have `extraction_status = success`; session must have 2-5 papers.
- **Errors:**
  - 400 - Extraction not yet complete for all papers
  - 404 - Session not found
  - 403 - Not session owner
  - 502 - Upstream AI provider failure (both Gemini and Groq failed)

---

### GET /analysis/{session_id}/result
- **Purpose:** Retrieve completed analysis results.
- **Auth:** Required (must own session)
- **Request:** None (path param `session_id`)
- **Response (200):**
```json
{
  "session_id": 12,
  "status": "complete",
  "summaries": [
    { "paper_id": 1, "title": "...", "summary": "..." },
    { "paper_id": 2, "title": "...", "summary": "..." }
  ],
  "comparison_table": [
    { "paper_id": 1, "methodology": "...", "dataset": "...", "results": "...", "limitations": "..." }
  ],
  "research_gaps": [ "Gap description 1", "Gap description 2" ],
  "survey_draft": "Draft literature survey paragraph text..."
}
```
- **Validation:** Session must belong to requesting user; status must be `complete` (otherwise returns current status without result fields).
- **Errors:**
  - 404 - Session not found
  - 403 - Not session owner
  - 202 (not an error) - Still processing, returns `{ "status": "processing" }`

---

## 4. Endpoint Summary Table

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | /auth/signup | No | Create account |
| POST | /auth/login | No | Get JWT |
| POST | /papers/upload | Yes | Upload 2-5 PDFs, create session |
| GET | /papers/session/{id} | Yes | Check extraction status |
| POST | /analysis/{id}/run | Yes | Trigger AI pipeline |
| GET | /analysis/{id}/result | Yes | Fetch results |

**Note:** No PUT/DELETE endpoints in v1 - matches MVP scope (no editing papers, no session management beyond create/view, consistent with "no scope creep" goal).
