# ARCHITECTURE.md
## PaperLens — System Architecture (Day 2)

---

## 1. Component Diagram

```mermaid
graph TD
    subgraph Client["Frontend (React + Vite + Tailwind)"]
        A1[Login/Signup Page]
        A2[Upload Page]
        A3[Comparison Table View]
        A4[Research Gap View]
        A5[Literature Survey Draft View]
    end

    subgraph Server["Backend (FastAPI)"]
        B1[Auth Router]
        B2[Upload Router]
        B3[Analysis Router]
        B4[PDF Extraction Service]
        B5[LLM Orchestration Service]
        B6[JWT Middleware]
    end

    subgraph DataLayer["Data Layer"]
        C1[(SQLite DB)]
        C2[Local File Storage - Uploaded PDFs]
    end

    subgraph External["External Services"]
        D1[Gemini API - Primary]
        D2[Groq API - Fallback]
    end

    A1 --> B1
    A2 --> B2
    A3 --> B3
    A4 --> B3
    A5 --> B3

    B1 --> B6
    B2 --> B6
    B3 --> B6

    B2 --> B4
    B4 --> C2
    B3 --> B5
    B5 --> D1
    B5 -->|on failure/rate limit| D2

    B1 --> C1
    B2 --> C1
    B3 --> C1
```

---

## 2. Data Flow Diagram

```mermaid
flowchart LR
    U[User] -->|Uploads 2-5 PDFs| UP[Upload Router]
    UP -->|Store raw files| FS[(File Storage)]
    UP -->|Extract text| EXT[PDF Extraction Service]
    EXT -->|Structured raw text per paper| DB[(SQLite: papers table)]
    DB -->|Feed extracted text| LLM[LLM Orchestration Service]
    LLM -->|Prompt: summarize| API1[Gemini/Groq API]
    API1 -->|Structured summary JSON| LLM
    LLM -->|Prompt: compare| API1
    API1 -->|Comparison table JSON| LLM
    LLM -->|Prompt: detect gaps| API1
    API1 -->|Gap list| LLM
    LLM -->|Prompt: draft survey| API1
    API1 -->|Survey paragraph| LLM
    LLM -->|Save results| DB
    DB -->|Return to client| U
```

---

## 3. Request Lifecycle (Sequence Diagram)

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant Backend
    participant Auth as JWT Middleware
    participant DB as SQLite
    participant LLM as LLM Service
    participant AI as Gemini/Groq

    User->>Frontend: Login (email, password)
    Frontend->>Backend: POST /auth/login
    Backend->>DB: Verify credentials
    DB-->>Backend: User record
    Backend-->>Frontend: JWT token
    Frontend-->>User: Redirect to Upload page

    User->>Frontend: Upload 2-5 PDFs
    Frontend->>Backend: POST /papers/upload (JWT attached)
    Backend->>Auth: Validate JWT
    Auth-->>Backend: OK
    Backend->>Backend: Extract text (PyMuPDF)
    Backend->>DB: Save papers + extracted text
    Backend->>LLM: Trigger analysis pipeline
    LLM->>AI: Send prompts (summarize/compare/gaps/survey)
    AI-->>LLM: Structured responses
    LLM->>DB: Save analysis results
    Backend-->>Frontend: Analysis complete + results
    Frontend-->>User: Render summaries, table, gaps, survey draft
```

---

## 4. AI Workflow Diagram

```mermaid
flowchart TD
    Start[Extracted text from 2-5 papers] --> Step1[Prompt 1: Structured Summary per paper]
    Step1 --> Step2[Prompt 2: Multi-paper Comparison - methodology, dataset, results, limitations]
    Step2 --> Step3[Prompt 3: Research Gap Detection across papers]
    Step3 --> Step4[Prompt 4: Literature Survey Paragraph Draft]
    Step4 --> Output[Return structured JSON: summaries, table, gaps, survey]

    Step1 -.->|API error/rate limit| Retry1[Retry with fallback provider]
    Step2 -.->|API error/rate limit| Retry2[Retry with fallback provider]
    Step3 -.->|API error/rate limit| Retry3[Retry with fallback provider]
    Step4 -.->|API error/rate limit| Retry4[Retry with fallback provider]

    Retry1 --> Step2
    Retry2 --> Step3
    Retry3 --> Step4
    Retry4 --> Output
```

---

## 5. External Services Diagram

```mermaid
graph LR
    Backend[FastAPI Backend] --> Gemini[Gemini API - Free Tier<br/>Primary LLM Provider]
    Backend --> Groq[Groq API - Free Tier<br/>Fallback LLM Provider]
    Backend --> Vercel[Vercel<br/>Frontend Hosting]
    Backend --> Render[Render<br/>Backend Hosting]
    Backend --> GitHub[GitHub<br/>Source Control + CI/CD trigger]

    Gemini -. rate limit fallback .-> Groq
```

---

## 6. Architecture Notes

- **Stateless backend**: JWT means no server-side session store needed — keeps SQLite simple (just a `users` table, no session table).
- **File storage**: Uploaded PDFs stored on local disk under the backend service (Render free tier has ephemeral storage — flagged as a **known limitation** for Day 3/4 discussion: files may not persist across redeploys. Acceptable for demo purposes since analysis results are persisted in SQLite, not the raw PDFs).
- **Fallback logic**: Any single LLM call failing (rate limit, timeout, error) triggers fallback to the secondary provider, not a full pipeline restart.
