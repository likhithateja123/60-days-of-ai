# IMPLEMENTATION-BLUEPRINT.md
## PaperLens — Updated Implementation Blueprint (Day 2)

> This document supersedes only the sections of the Day 1 Blueprint affected by two approved changes below. All other Day 1 decisions remain unchanged.

---

## 1. Approved Changes Log (Day 2)

| # | Change | Status | Reason |
|---|--------|--------|--------|
| 1 | Authentication moved from **Out of Scope** → **In Scope (Simple)** | ✅ Approved by stakeholder | Explicit instruction during Day 2 stack finalization |
| 2 | AI Model/API locked to **hosted free-tier API** (Gemini or Groq) | ✅ Approved by stakeholder | Explicit instruction during Day 2 stack finalization |

**Assumption (flagged, not yet explicitly confirmed):** "Simple auth" = email + password, hashed with bcrypt, session managed via JWT. No OAuth, no roles, no email verification, no password reset flow (can be added post-capstone if time allows). This keeps auth from re-introducing "multi-user collaboration," which remains explicitly out of scope.

**Impact of Change #1 on scope:**
- Adds: 1 login screen, 1 signup screen, 2 backend endpoints, 1 `users` table, JWT middleware.
- Does NOT add: user roles, shared workspaces, paper sharing between users, admin panel.
- Time cost estimate: ~0.5–1 day of the remaining 8 days. Still realistic — see Readiness Review in this doc.

---

## 2. Finalized Tech Stack

| Layer | Choice | Justification |
|---|---|---|
| **Frontend** | React (Vite) + Tailwind CSS | Fast local dev server, no build config overhead, Tailwind speeds up building clean responsive UI within tight timeline |
| **Backend** | Python + FastAPI | Native async, automatic OpenAPI/Swagger docs (accelerates Day 3 dev + testing), best-in-class Python AI/PDF library support |
| **Database** | SQLite | Zero infrastructure setup, file-based, free, sufficient for single-tenant-per-user MVP scale; avoids Postgres ops overhead in a 10-day window |
| **Authentication** | Custom simple auth: bcrypt password hashing + JWT session tokens | Meets "simple auth" requirement without external dependency cost or OAuth app registration overhead |
| **AI Model/API** | Gemini API (free tier) as primary, Groq (free tier, Llama/Mixtral models) as fallback | Free-tier hosted APIs avoid local GPU/compute requirements; using two providers with a fallback path protects against free-tier rate limits during demo/testing |
| **Hosting** | Frontend: Vercel (free tier) · Backend: Render (free tier) | Both offer zero-cost deploys with GitHub CI/CD integration, matching "free/open-source tools only" constraint |
| **Core Libraries** | `PyMuPDF` (PDF text extraction), `passlib`+`bcrypt` (password hashing), `python-jose` (JWT), `pandas` (comparison table structuring), `httpx` (async API calls to LLM providers) | All free/open-source, minimal setup, well documented |

---

## 3. Readiness Review

**Remaining scope realistic?** ✅ Yes.
- Core MVP features (upload, summarize, compare, gap detection, survey draft, deploy) were already scoped for 10 days pre-auth.
- Simple auth adds ~0.5–1 day; still fits within remaining 8 days if Day 3 starts implementation immediately.

**Any scope creep?** ⚠️ One controlled addition (auth), explicitly approved and bounded above. No other creep — Out-of-Scope list (chat with papers, citation graphs, collaboration, LaTeX/Word export) remains fully excluded.

**Can Day 3 begin implementation immediately?** ✅ Yes, once you confirm the documents below (Architecture, Schema, API, Wireframes, Project Structure).

---

## 4. Open Items Requiring Your Confirmation Before Day 3

1. Confirm the bcrypt+JWT "simple auth" assumption above, or specify a different simple mechanism.
2. Confirm Gemini as primary / Groq as fallback (or reverse priority, or single-provider only).
3. Confirm SQLite is acceptable for the demo (vs. requesting Postgres despite added setup time).

No production code has been written today, per instructions.
