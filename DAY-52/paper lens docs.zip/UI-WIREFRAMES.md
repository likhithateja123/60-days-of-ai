# UI-WIREFRAMES.md
## PaperLens - UI Design (Day 2)

---

## 1. User Flow

```mermaid
flowchart TD
    A[Land on App] --> B{Logged in?}
    B -->|No| C[Login/Signup Page]
    C --> D[Upload Page]
    B -->|Yes| D
    D --> E[Select 2-5 PDF files]
    E --> F[Submit Upload]
    F --> G[Processing Screen - extracting text + running AI]
    G --> H[Results Dashboard]
    H --> I[Tab: Summaries]
    H --> J[Tab: Comparison Table]
    H --> K[Tab: Research Gaps]
    H --> L[Tab: Literature Survey Draft]
```

---

## 2. Screen Flow

```mermaid
flowchart LR
    S1[Login/Signup] --> S2[Upload Screen]
    S2 --> S3[Processing/Loading Screen]
    S3 --> S4[Results Dashboard]
    S4 --> S2
```

**Screen list:**
1. Login/Signup Screen
2. Upload Screen
3. Processing Screen
4. Results Dashboard (tabbed: Summaries / Comparison / Gaps / Survey Draft)

---

## 3. Low-Fidelity Wireframes (ASCII)

### Screen 1: Login/Signup
```
+--------------------------------------------------+
|                   PaperLens                       |
|                                                    |
|   [ Toggle: Login | Sign Up ]                     |
|                                                    |
|   Email:    [____________________]               |
|   Password: [____________________]               |
|                                                    |
|            [   Continue  ]                        |
|                                                    |
+--------------------------------------------------+
```

### Screen 2: Upload
```
+--------------------------------------------------+
|  PaperLens          [User email]  [Logout]        |
+--------------------------------------------------+
|                                                    |
|   Upload 2-5 research papers (PDF)                |
|                                                    |
|   +--------------------------------------+        |
|   |   Drag & drop files here, or browse   |        |
|   +--------------------------------------+        |
|                                                    |
|   Selected files:                                 |
|   - paper1.pdf   [x]                              |
|   - paper2.pdf   [x]                              |
|                                                    |
|   Session title (optional): [________________]    |
|                                                    |
|              [   Analyze Papers   ]                |
|                                                    |
+--------------------------------------------------+
```

### Screen 3: Processing
```
+--------------------------------------------------+
|  PaperLens                                        |
+--------------------------------------------------+
|                                                    |
|              [ spinner/progress bar ]             |
|                                                    |
|        Extracting text from papers...             |
|        Generating summaries...                    |
|        Comparing methodologies...                 |
|        Detecting research gaps...                 |
|        Drafting literature survey...               |
|                                                    |
+--------------------------------------------------+
```

### Screen 4: Results Dashboard
```
+--------------------------------------------------+
|  PaperLens          [User email]  [Logout]        |
+--------------------------------------------------+
|  [Summaries] [Comparison] [Gaps] [Survey Draft]   |
+--------------------------------------------------+
|                                                    |
|  (Tab: Summaries)                                 |
|  Paper 1: Title                                   |
|    - Summary text block...                        |
|  Paper 2: Title                                   |
|    - Summary text block...                        |
|                                                    |
|  (Tab: Comparison) - table view                   |
|  | Paper | Method | Dataset | Results | Limits |  |
|                                                    |
|  (Tab: Gaps) - bullet list                        |
|  - Gap 1 description                              |
|  - Gap 2 description                              |
|                                                    |
|  (Tab: Survey Draft) - text block, copyable        |
|                                                    |
|              [ New Analysis ]                      |
+--------------------------------------------------+
```

---

## 4. Navigation Rules

- Unauthenticated users are redirected to Login/Signup for any route other than that screen.
- After successful login/signup, user always lands on Upload Screen (no persistent "last session" restore in MVP).
- "New Analysis" button on Results Dashboard returns to Upload Screen, starting a fresh session.
- No back-navigation into Processing Screen once results are ready (avoids re-triggering analysis).
- Responsive breakpoints: stacked/mobile layout collapses tabs into an accordion or dropdown selector below ~640px width (Tailwind `sm:` breakpoint).
