# PROJECT-STRUCTURE.md
## PaperLens - Project Folder Organization (Day 2)

---

## 1. Repository Layout

```
paperlens/
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── LoginSignup.jsx
│   │   │   ├── Upload.jsx
│   │   │   ├── Processing.jsx
│   │   │   └── ResultsDashboard.jsx
│   │   ├── components/
│   │   │   ├── FileDropzone.jsx
│   │   │   ├── ComparisonTable.jsx
│   │   │   ├── GapList.jsx
│   │   │   ├── SurveyDraftView.jsx
│   │   │   └── NavTabs.jsx
│   │   ├── api/
│   │   │   └── client.js          # centralized fetch wrapper, attaches JWT
│   │   ├── context/
│   │   │   └── AuthContext.jsx    # stores JWT + user email in memory
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── tailwind.config.js
│   ├── vite.config.js
│   └── package.json
│
├── backend/
│   ├── app/
│   │   ├── main.py                # FastAPI app entrypoint
│   │   ├── routers/
│   │   │   ├── auth.py            # /auth/signup, /auth/login
│   │   │   ├── papers.py          # /papers/upload, /papers/session/{id}
│   │   │   └── analysis.py        # /analysis/{id}/run, /analysis/{id}/result
│   │   ├── services/
│   │   │   ├── pdf_extraction.py  # PyMuPDF text extraction logic
│   │   │   ├── llm_orchestration.py  # prompt building + Gemini/Groq calls
│   │   │   └── auth_service.py    # bcrypt hashing, JWT issue/verify
│   │   ├── models/
│   │   │   ├── user.py
│   │   │   ├── session.py
│   │   │   ├── paper.py
│   │   │   └── analysis_result.py
│   │   ├── schemas/                # Pydantic request/response models
│   │   │   ├── auth_schemas.py
│   │   │   ├── paper_schemas.py
│   │   │   └── analysis_schemas.py
│   │   ├── db/
│   │   │   ├── database.py        # SQLite connection/session setup
│   │   │   └── init_db.py         # table creation script
│   │   └── middleware/
│   │       └── jwt_middleware.py
│   ├── storage/
│   │   └── uploads/                # uploaded PDF files (local disk)
│   ├── requirements.txt
│   └── .env.example                 # GEMINI_API_KEY, GROQ_API_KEY, JWT_SECRET
│
├── docs/                             # Day 1 + Day 2 deliverables
│   ├── PRD.md
│   ├── IMPLEMENTATION-BLUEPRINT.md
│   ├── ARCHITECTURE.md
│   ├── SCHEMA.md
│   ├── API.md
│   ├── UI-WIREFRAMES.md
│   └── PROJECT-STRUCTURE.md
│
├── .gitignore
└── README.md
```

---

## 2. Folder Responsibilities

| Folder/File | Responsibility |
|---|---|
| `frontend/src/pages/` | One file per screen, matches Screen Flow in UI-WIREFRAMES.md |
| `frontend/src/components/` | Reusable UI pieces used across pages |
| `frontend/src/api/client.js` | Single place all HTTP calls go through; attaches JWT header automatically |
| `frontend/src/context/AuthContext.jsx` | In-memory auth state (no localStorage dependency required, though may be added later for persistence across refresh) |
| `backend/app/routers/` | One file per resource group, matches API.md endpoint groupings exactly |
| `backend/app/services/` | Business logic isolated from routing - keeps routers thin |
| `backend/app/models/` | ORM/data models matching SCHEMA.md tables 1:1 |
| `backend/app/schemas/` | Pydantic validation models - enforces API.md request/response contracts |
| `backend/app/db/` | DB connection setup and initial table creation |
| `backend/storage/uploads/` | Raw PDF file storage (flagged in ARCHITECTURE.md as ephemeral on Render free tier) |
| `docs/` | All approved planning documents kept alongside code for traceability |

---

## 3. Day 3 Starting Point

Day 3 can begin directly with:
1. `backend/app/db/init_db.py` - create tables from SCHEMA.md
2. `backend/app/routers/auth.py` - implement signup/login per API.md
3. `frontend/src/pages/LoginSignup.jsx` - implement per UI-WIREFRAMES.md Screen 1

No architectural decisions remain open except the three confirmation items listed in IMPLEMENTATION-BLUEPRINT.md Section 4.
